# TT_MiniSumo_Arruela (v1.0)
 Mini Sumo da Tamandutech - ARRUELA!

## Pastas e Arquivos
```
Autonomo
|--lib
|  |--core
|     |- core.cpp
|     |- core.hpp
|  |--robo
|     |- robo.cpp
|     |- robo.hpp
|--src
   |- main.cpp
```

## Codigo
 Esse código é uma experiência de criar uma nova organização que tem como principio facilitar a manutenção.
